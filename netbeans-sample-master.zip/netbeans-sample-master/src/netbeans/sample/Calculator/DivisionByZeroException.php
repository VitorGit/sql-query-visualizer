<?php
namespace netbeans\sample\Calculator;


class DivisionByZeroException extends \Exception
{

}
